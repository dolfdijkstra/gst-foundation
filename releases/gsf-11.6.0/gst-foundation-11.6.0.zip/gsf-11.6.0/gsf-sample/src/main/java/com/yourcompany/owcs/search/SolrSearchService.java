package com.yourcompany.owcs.search;

public interface SolrSearchService {

    SearchResults search(String string);

}
